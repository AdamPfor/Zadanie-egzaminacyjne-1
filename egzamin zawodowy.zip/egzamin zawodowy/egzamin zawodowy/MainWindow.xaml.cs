﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace egzamin_zawodowy
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Uri postcardImg = new Uri("/pocztowka.jpg", UriKind.Relative);
        Uri letterImg = new Uri("/list.jpg", UriKind.Relative);
        Uri packageImg = new Uri("/paczka.jpg", UriKind.Relative);


        //nie działa zmienianie obrazków
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (Pocztowka.IsChecked == true)
            {
                cena.Content = "Cena: 1zł";
                
            }
            if (List.IsChecked == true)
            {
                cena.Content = "Cena: 1,5zł";
             
            }
            if (Paczka.IsChecked == true)
            {
                cena.Content = "Cena: 10zł";
                
            }
        
    }



        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string postalCode = KodPocztowy.Text;
            if (postalCode.Length == 5)
            {
                try
                {
                    int numericPostalCode = Convert.ToInt32(KodPocztowy.Text);
                    MessageBox.Show("Dane przesyłki zostały wprowadzone");
                }
                catch (System.FormatException)
                {
                    MessageBox.Show("Kod pocztowy powinien się składać z samych cyfr");
                }
            }
            else
            {
                MessageBox.Show("Nieprawidłowa długość kodu pocztowego");
            }
        }
    }
}